# dokuwiki-https
 Python (pip) module to interface with dokuwiki over https (as opposed to XML-RPC)
